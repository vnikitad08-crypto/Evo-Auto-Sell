package me.sh1zaexe.evoasell.gui;

import me.sh1zaexe.evoasell.EvoAsellClient;
import me.sh1zaexe.evoasell.config.EvoAsellConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * In-game settings screen for EvoAsell.
 *
 * Layout (centred, dark panel):
 * ┌─────────────────────────────────────────────┐
 * │            EvoAsell Settings                │
 * │                                             │
 * │  ── Auto Message ─────────────────────────  │
 * │  Message: [____________________________]    │
 * │  Interval (sec): [____]                     │
 * │  Auto Send:  [ ENABLED / DISABLED ]         │
 * │                                             │
 * │  ── Nickname Highlight ────────────────────  │
 * │  Nick Highlight: [ ENABLED / DISABLED ]     │
 * │                                             │
 * │                  [ Save & Close ]           │
 * └─────────────────────────────────────────────┘
 */
public class EvoAsellScreen extends class_437 {

    private static final int PANEL_W = 320;
    private static final int PANEL_H = 220;

    // Colours
    private static final int COL_BG        = 0xCC0D0D0D; // semi-transparent black
    private static final int COL_BORDER     = 0xFF5A8AFF; // electric blue border
    private static final int COL_TITLE      = 0xFF5A8AFF;
    private static final int COL_SECTION    = 0xFFAAAAAA;
    private static final int COL_LABEL      = 0xFFFFFFFF;
    private static final int COL_BTN_ON_BG  = 0xFF1C5C1C; // dark green
    private static final int COL_BTN_OFF_BG = 0xFF5C1C1C; // dark red

    private final class_437 parent;

    // Widgets
    private class_342 messageField;
    private class_342 intervalMinutesField;
    private class_342 intervalSecondsField;
    private class_4185   autoSendToggle;

    // Local copies of config values (applied only on Save)
    private boolean autoEnabled;

    public EvoAsellScreen(class_437 parent) {
        // Заголовок оставляем на английском, как просил пользователь
        super(class_2561.method_43470("EvoAsell Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        EvoAsellConfig cfg = EvoAsellConfig.getInstance();
        autoEnabled      = cfg.autoMessageEnabled;

        int px = (field_22789  - PANEL_W) / 2;
        int py = (field_22790 - PANEL_H) / 2;

        // ── Auto-message text field ───────────────────────────────────────────
        messageField = new class_342(field_22793,
                px + 10, py + 60, PANEL_W - 20, 18,
                class_2561.method_43470("Сообщение"));
        messageField.method_1880(256);
        messageField.method_1852(cfg.autoMessageText);
        messageField.method_47404(class_2561.method_43470("Ваше авто-сообщение..."));
        method_37063(messageField);

        // ── Interval fields (minutes + seconds) ───────────────────────────────
        int totalSecs = Math.max(1, cfg.autoMessageInterval);
        int minutes   = totalSecs / 60;
        int seconds   = totalSecs % 60;

        intervalMinutesField = new class_342(field_22793,
                px + 110, py + 96, 40, 18,
                class_2561.method_43470("Минуты"));
        intervalMinutesField.method_1880(3);
        intervalMinutesField.method_1852(String.valueOf(minutes));
        intervalMinutesField.method_47404(class_2561.method_43470("0"));
        method_37063(intervalMinutesField);

        intervalSecondsField = new class_342(field_22793,
                px + 160, py + 96, 40, 18,
                class_2561.method_43470("Секунды"));
        intervalSecondsField.method_1880(2);
        intervalSecondsField.method_1852(String.valueOf(seconds));
        intervalSecondsField.method_47404(class_2561.method_43470("1"));
        method_37063(intervalSecondsField);

        // ── Auto-send toggle ──────────────────────────────────────────────────
        autoSendToggle = class_4185.method_46430(autoSendLabel(), btn -> {
            autoEnabled = !autoEnabled;
            btn.method_25355(autoSendLabel());
        }).method_46434(px + 10, py + 125, 140, 20).method_46431();
        method_37063(autoSendToggle);

        // ── Save & Close ──────────────────────────────────────────────────────
        class_4185 saveBtn = class_4185.method_46430(
                class_2561.method_43470("Сохранить и закрыть"), btn -> saveAndClose()
        ).method_46434(px + (PANEL_W / 2) - 60, py + PANEL_H - 28, 120, 20).method_46431();
        method_37063(saveBtn);
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Dim the game world behind the screen
        method_25420(ctx, mouseX, mouseY, delta);

        int px = (field_22789  - PANEL_W) / 2;
        int py = (field_22790 - PANEL_H) / 2;

        // Panel background
        ctx.method_25294(px, py, px + PANEL_W, py + PANEL_H, COL_BG);

        // Border – 1 px
        ctx.method_49601(px, py, PANEL_W, PANEL_H, COL_BORDER);

        // ── Title ─────────────────────────────────────────────────────────────
        ctx.method_27534(field_22793,
                class_2561.method_43470("EvoAsell  |  sh1zaExE"),
                field_22789 / 2, py + 8, COL_TITLE);

        // ── Section: Auto Message ─────────────────────────────────────────────
        ctx.method_27535(field_22793,
                class_2561.method_43470("-- Авто-сообщение --"), px + 10, py + 34, COL_SECTION);
        ctx.method_27535(field_22793,
                class_2561.method_43470("Сообщение:"), px + 10, py + 46, COL_LABEL);
        ctx.method_27535(field_22793,
                class_2561.method_43470("Интервал:"), px + 10, py + 82, COL_LABEL);

        // Render children (widgets) on top
        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private class_2561 autoSendLabel() {
        return autoEnabled
                ? class_2561.method_43470("  ВКЛ  ").method_54663(0xFF55FF55)
                : class_2561.method_43470("  ВЫКЛ ").method_54663(0xFFFF5555);
    }

    private void saveAndClose() {
        EvoAsellConfig cfg = EvoAsellConfig.getInstance();

        boolean wasAutoEnabled = cfg.autoMessageEnabled;

        cfg.autoMessageEnabled  = autoEnabled;
        cfg.autoMessageText     = messageField.method_1882();

        try {
            int mins = Integer.parseInt(intervalMinutesField.method_1882().trim());
            int secs = Integer.parseInt(intervalSecondsField.method_1882().trim());
            int total = mins * 60 + secs;
            cfg.autoMessageInterval = Math.max(1, total); // минимум 1 секунда
        } catch (NumberFormatException ignored) {
            // Если введено что-то нечисловое — оставляем старое значение
        }

        cfg.save();

        // Reset the auto-message countdown so new interval takes effect immediately
        EvoAsellClient.getAutoMessageManager().resetTimer();

        // Если авто-сообщение только что включили — сразу отправляем первое.
        if (!wasAutoEnabled && cfg.autoMessageEnabled) {
            EvoAsellClient.getAutoMessageManager().triggerImmediate();
        }

        method_25419();
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false; // game keeps running while screen is open
    }
}
