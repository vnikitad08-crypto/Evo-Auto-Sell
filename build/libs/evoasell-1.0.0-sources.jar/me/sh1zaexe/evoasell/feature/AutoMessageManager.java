package me.sh1zaexe.evoasell.feature;

import me.sh1zaexe.evoasell.EvoAsell;
import me.sh1zaexe.evoasell.config.EvoAsellConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

/**
 * Manages the timed auto-chat-message loop on the client side.
 *
 * Call {@link #tick()} every client tick (from the ClientTickEvent).
 * When the configured interval elapses and the feature is enabled,
 * the stored message is sent to the server chat.
 */
public class AutoMessageManager {

    /** Ticks per second in Minecraft. */
    private static final int TPS = 20;

    /** Счётчик до следующего авто-сообщения (в тиках). */
    private int tickCounter = 0;

    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Called every client game tick.
     * Sends the configured message when the countdown reaches zero.
     */
    public void tick() {
        EvoAsellConfig cfg = EvoAsellConfig.getInstance();

        if (!cfg.autoMessageEnabled) {
            tickCounter = 0;
            return;
        }

        tickCounter++;
        int targetTicks = cfg.autoMessageInterval * TPS;

        if (tickCounter >= targetTicks) {
            tickCounter = 0;
            sendMessage(cfg.autoMessageText);
        }
    }

    /**
     * Resets the internal countdown.
     * Call this after the user changes the interval so the new setting
     * takes effect immediately without waiting for the old countdown to expire.
     */
    public void resetTimer() {
        tickCounter = 0;
    }

    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Отправить авто-сообщение немедленно (если включено в конфиге),
     * и сбросить таймер, чтобы следующий запуск шёл по интервалу.
     */
    public void triggerImmediate() {
        EvoAsellConfig cfg = EvoAsellConfig.getInstance();
        if (!cfg.autoMessageEnabled) {
            return;
        }
        tickCounter = 0;
        sendMessage(cfg.autoMessageText);
    }

    // ─────────────────────────────────────────────────────────────────────────

    private void sendMessage(String message) {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;

        if (message == null || message.isBlank()) {
            EvoAsell.LOGGER.warn("[EvoAsell] AutoMessage text is empty – skipping send.");
            return;
        }

        // Trim to 256 chars to avoid server kick for too-long messages
        String trimmed = message.length() > 256 ? message.substring(0, 256) : message;

        try {
            client.field_1724.field_3944.method_45729(trimmed);

            // Лёгкий звуковой сигнал.
            if (client.method_1483() != null) {
                client.method_1483().method_4873(
                        net.minecraft.class_1109.method_4757(
                                net.minecraft.class_3417.field_15015.comp_349(), 1.0f, 1.1f
                        )
                );
            }

            // Если интервал авто-сообщения 2 минуты и больше — пишем тихое уведомление в чат.
            EvoAsellConfig cfg = EvoAsellConfig.getInstance();
            if (cfg.autoMessageInterval >= 120 && client.field_1705 != null) {
                class_2561 info = class_2561.method_43473()
                        .method_10852(class_2561.method_43470("EvoAsell ").method_27692(class_124.field_1060))
                        .method_10852(class_2561.method_43470("» ").method_27692(class_124.field_1080))
                        .method_10852(class_2561.method_43470("Сообщение было успешно отправлено").method_27692(class_124.field_1054));

                client.field_1705.method_1743().method_1812(info);
            }
        } catch (Exception e) {
            EvoAsell.LOGGER.error("[EvoAsell] Failed to send auto-message: {}", e.getMessage());
        }
    }
}
