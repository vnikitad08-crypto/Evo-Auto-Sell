package me.sh1zaexe.evoasell.mixin;

import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Пустой миксин. Оставляем класс, чтобы сохранить структуру конфигурации,
 * но не внедряемся в методы ChatHud (во избежание крашей на новых версиях).
 *
 * Логика звука по триггеру "» Я:" перенесена в Fabric-эвент чата
 * внутри {@code EvoAsellClient}.
 */
@Mixin(class_338.class)
public abstract class ChatHudMixin {
}
